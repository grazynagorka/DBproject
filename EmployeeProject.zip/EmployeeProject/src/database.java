import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class database {
     private static database inst; //singleton
     private Connection conn;
     private Statement stmt;
     
     public static synchronized database getInst() //singleton
    {
        if(inst==null) inst = new database();
        return inst;
    }
    
   public void connect(String USER, String PASS) throws SQLException
    {
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@155.158.112.45:1521:oltpstud", USER,PASS);
            stmt = conn.createStatement();
            
        } catch (ClassNotFoundException ex) {
           System.err.println("EEEEEEEEEError" +ex.getMessage());
        } 
        
    }
    
    public ResultSet executeQuery(String query)
    {
        
        if (conn!=null) 
        {
            try {
	          return stmt.executeQuery(query);
		} catch (SQLException e) 
                    {
			return null;
		    }
        }
        else return null;
    }
    
    public int executeUpdate(String query){
		
		if(conn!=null)		
		try {
			return stmt.executeUpdate(query);
                    } catch (SQLException e) {
			return 0;
		}
                else return 0;
	}
    
    public void disconnect() {
        try { if(conn!=null)
              { stmt.close();
                conn.close();}
        } catch (SQLException ex) {
           System.err.println("Error: "+ex.getMessage());
        }
}
}
